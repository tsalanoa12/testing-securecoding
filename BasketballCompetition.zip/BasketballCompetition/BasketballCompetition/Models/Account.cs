﻿using System;
using System.Collections.Generic;

namespace BasketballCompetition.Models
{
    public partial class Account
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
